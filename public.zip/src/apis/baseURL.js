export default {
    baseApiURL: import.meta.env.VITE_BASE_API_URL,
    baseURL: import.meta.env.VITE_BASE_URL
}