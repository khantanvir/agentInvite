export interface Link {
  url: string
  label: string
  active: boolean
}
