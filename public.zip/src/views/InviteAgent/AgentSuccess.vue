<template>
    <div class="jumbotron text-center">
        <h1 class="display-3">Thank You!</h1>
            <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
        <hr>
        <p>
            Having trouble? <a href="https://www.boosteducationservice.co.uk/contact-us/" target="_blank" class="text-blue-700 font-bold">Contact us</a>
        </p>
        <p class="lead">
            <a class="btn btn-primary btn-sm mt-2" href="https://www.boosteducationservice.co.uk/" target="_blank" role="button">Continue to homepage</a>
        </p>
</div>
</template>
<style>
    
.jumbotron{
    margin: 0 auto;
    width: 50%;
    margin-top: 78px;
}
@media (max-width: 768px) {
    .jumbotron {
        margin-top: 5px;
        width: 80%;

        }
}

@media (max-width: 576px) {
.jumbotron {

           margin-top: 5px;
           width: 80%;
    }
}
</style>